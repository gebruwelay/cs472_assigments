package miu.edu.controller;

import miu.edu.domain.Post;
import miu.edu.domain.User;
import miu.edu.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/admin")
public class UserController {
    UserService userService;

    @Autowired
    public void setUserService(UserService userService) {
        this.userService = userService;
    }

    //Q-1: retrieve all the users
    @GetMapping
    public Iterable<User> getAll() {
        return userService.findAll();
    }

    //Q-2: retrieve the user with id = ?
    @GetMapping("/{id}")
    public Optional<User> find(@PathVariable("id") long id) {
        return userService.findById(id);
    }

    //Q-3: create and save a new user
    @PostMapping
    public void save(@RequestBody User user) {
        userService.save(user);
    }

    //Q-4: retrieve the posts of the user where id = 1.
    @GetMapping("/{id}/posts")
    public List<Post> getPosts(@PathVariable("id") long id) {
        return userService.getPosts(id);
    }

    //Q-5: Make a query that will return all the users that have more than 1 post
    @GetMapping("/posts")
    public List<User> getUsersWhoHavePosts() {
        return userService.getUsersWhoHavePosts();
    }

    /*===========   I added the following for my personal exercise on JPQL and Native queries   ===========*/

    //1: retrieve all users with this 'firstName'
    @GetMapping("/name/{firstName}")
    public List<User> getAllUsersWithFirstName(@PathVariable("firstName") String firstName) {
        return userService.getAllUsersWithFirstName(firstName);
    }

    //2: retrieve all users with this 'firstName' and 'lastName'
    @GetMapping("/{firstName}/{lastName}")
    public List<User> getAllUsersWithFirstName(@PathVariable("firstName") String firstName,
                                               @PathVariable("lastName") String lastName) {
        return userService.findUserByFullName(firstName, lastName);
    }
}
