package miu.edu.service;

import miu.edu.domain.Post;

import java.util.Optional;

public interface PostService {

    void save(Post post);

    Optional<Post> findById(long id);

    boolean existsById(long id);

    Iterable<Post> findAll();

    void deleteById(long id);
}
