package miu.edu.service;

import miu.edu.domain.Post;
import miu.edu.domain.User;
import miu.edu.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserServiceImple implements UserService {
    UserRepository userRepository;

    @Autowired
    public void setUserRepository(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public void save(User user) {
        userRepository.save(user);
    }

    @Override
    public Iterable<User> findAll() {
        return userRepository.findAll();
    }
    @Override
    public Optional<User> findByUsername(String username){
        return userRepository.findByUsername(username);
    }

    @Override
    public Optional<User> findById(long id) {
        return userRepository.findById(id);
    }

    @Override
    public List<Post> getPosts(long id) {
        return userRepository.getPosts(id);
    }

    @Override
    public List<User> getUsersWhoHavePosts() {
        return userRepository.getUsersWhoHavePosts();
    }

    @Override
    public List<User> getAllUsersWithFirstName(String firstName) {
        return userRepository.getAllUsersWithFirstName(firstName);
    }

    @Override
    public List<User> findUserByFullName(String firstName, String secondName) {
        return userRepository.findUserByFullName(firstName, secondName);
    }
}
