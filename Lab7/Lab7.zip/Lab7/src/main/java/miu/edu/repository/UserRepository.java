package miu.edu.repository;

import miu.edu.domain.Post;
import miu.edu.domain.User;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserRepository extends CrudRepository<User, Long> {

    @Query("SELECT u FROM User u WHERE u.username = ?1")
    Optional<User> findByUsername(@Param("username") String username);

    @Query("Select u.posts from User u where u.id = :id")
    List<Post> getPosts(@Param("id") long id);

    @Query(value = "Select * from User where first_name like %:first_name%", nativeQuery = true)
    List<User> getAllUsersWithFirstName(@Param("first_name") String firstName);

    @Query("SELECT u FROM User u WHERE u.firstName = ?1 and u.lastName = ?2")
    List<User> findUserByFullName(@Param("firstName") String firstName, @Param("lastName") String lastName);

    @Query("SELECT u FROM User u WHERE u.posts.size > 1")
    List<User> getUsersWhoHavePosts();
}
