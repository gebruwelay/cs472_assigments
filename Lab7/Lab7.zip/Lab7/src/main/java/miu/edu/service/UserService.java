package miu.edu.service;

import miu.edu.domain.Post;
import miu.edu.domain.User;

import java.util.List;
import java.util.Optional;

public interface UserService {
    void save(User user);

    Iterable<User> findAll();

    Optional<User> findById(long id);

    Optional<User> findByUsername(String username);

    List<Post> getPosts(long id);

    List<User> getUsersWhoHavePosts();

    List<User> getAllUsersWithFirstName(String firstName);

    List<User> findUserByFullName(String firstName, String lastName);
}
