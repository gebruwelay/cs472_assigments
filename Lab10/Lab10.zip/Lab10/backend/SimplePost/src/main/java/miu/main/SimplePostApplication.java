package miu.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimplePostApplication {

    public static void main(String[] args) {

        SpringApplication.run(SimplePostApplication.class, args);
    }

}
