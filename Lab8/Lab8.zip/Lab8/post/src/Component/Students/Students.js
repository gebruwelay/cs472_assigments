import React from 'react';
import './Students.css'

function Students (props){
    const { student, idx } = props;
    const ID = student.id;
    console.log(ID)
    return (
        <div  id = {ID} className = "boxes">
        <p> Student</p>
        <p> ID: {student.id} </p>
        <p> Name: {student.name}</p>
        <p> Major: {student.major} </p>
        </div>
    )
}

export default Students;