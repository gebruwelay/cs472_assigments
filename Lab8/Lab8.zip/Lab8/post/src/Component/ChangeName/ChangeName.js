import React from 'react'
import './ChangeName.css'
function ChangeName() {
    return (
        <div id = "editStudent">
            <p>Change Name: <input id = "first" type = "text"/> </p>
            <button onClick = {() =>{
                const newName = document.getElementById("first").value;
                document.getElementById("111").children[2].innerHTML = `Name: ${newName}`;
            }}>Change</button>
         </div>
    )
}

export default ChangeName