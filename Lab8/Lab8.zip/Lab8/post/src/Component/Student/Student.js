import React from 'react';
import Students from '../Students/Students';
import  './Student.css';

function Student () {
    const studentList = [
        {
            id: "111",
            name: "Meti",
            major: "CS"
        },
        {
            id: "112",
            name: "Tedros",
            major: "CS"
        },
        {
            id: "113",
            name: "pascal",
            major: "CS"
        }
    ]

    const result = studentList.map((stu,idx) =>
        <Students student= {stu} index= {idx} key={idx}></Students>);
    return (
        <div id ="studentsContainer" >
            {result}
        </div>
    )
}

export default Student;