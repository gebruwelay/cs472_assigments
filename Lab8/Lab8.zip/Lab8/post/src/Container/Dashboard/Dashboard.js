import React, {PureComponent } from "react";
import Student from "../../Component/Student/Student";
import ChangeName from "../../Component/ChangeName/ChangeName";
import './Dashboard.css';

function Dashboard() {
  
        return (
            <div id = "dashboard">
                <Student/>
                <ChangeName/>
            </div>
        )
 
}

export default Dashboard;