import React, { useState } from 'react';
import NewPost from '../../components/NewPost/NewPost';
import './Blog.css';
import Posts from '../Posts/Posts'
import FullPost from '../../components/FullPost/FullPost'
import { LikedPosts } from '../../store/LikedPosts';
import { APIConfig } from '../../store/API-Config';
import { Test } from '../Posts/Test';
import Header from '../Header/Header';
import Routes from '../Routes/Routes';
import { Route, Link, Switch, Redirect } from 'react-router-dom';

const Blog = (props) => {

    const [likedPosts, setLikedPosts] = useState([]);
    const base = 'http://localhost:8080';

    return (
        <LikedPosts.Provider value={{ likedPosts, setLikedPosts }}>
            <APIConfig.Provider value={
                {
                    postAPI: base + '/posts/',
                    userAPI: base + '/users/'
                }
            }>
                <div className="Blog">
                    <Header />

                   <Switch>
                        
                        <Route path="/posts" component={Posts} />
                        <Route path="/newpost" component={NewPost} />
                        <Redirect from="/" to="/posts" />      {/* This will change the url*/}
                        {/* <Redirect from="/" to="/posts" />      This will change the url */}
                        {/* <Route render={()=> <h1> Page Not Found</h1>} />  */}
                 </Switch>
                    
                </div>


            </APIConfig.Provider>
        </LikedPosts.Provider >
    );
}


export default Blog;

