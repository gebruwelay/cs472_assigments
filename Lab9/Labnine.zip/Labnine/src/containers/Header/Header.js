import React from "react";
import { Link } from 'react-router-dom';

const Header = () => {

    return(
        <header>
                        <nav>
                            <ul>
                                <li><Link to="/posts"> Posts</Link></li>
                                <li><Link to={{
                                    pathname: '/newpost',                      // props.match.url + to get 
                                    hash: '#submit',
                                    search: '?quick-submit=true'
                                }}>New Post</Link></li>
                            </ul>
                        </nav>
                    </header>
    );
}

export default Header;