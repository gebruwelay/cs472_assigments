import React from "react";
import { Route, Link, Switch, Redirect } from 'react-router-dom';

const Routes = () => {

    // return (
    //     <Switch>
    //         <Route path="/new-post" component={NewPost} />
    //         <Route path="/posts" component={Posts} />
    //         <Redirect from="/" to="/posts" />      This will change the url
    //         {/* <Route render={()=> <h1> Page Not Found</h1>} />  */}
    //     </Switch>
    // );

}

export default Routes;