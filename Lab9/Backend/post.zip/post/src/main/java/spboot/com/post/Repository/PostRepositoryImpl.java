package spboot.com.post.Repository;

import org.springframework.stereotype.Repository;
import spboot.com.post.domain.Post;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Repository
public class PostRepositoryImpl   {

    List<Post> posts = new ArrayList<>(Arrays.asList(new Post(1,"Dr.","hi Dr.","Gberu"),
            new Post(2,"Mr.","Hi Mr.","Birhane")));

    public List<Post> getAll() {
        return posts;
    }


    public Optional<Post> getPostById(Integer id) {
        return  posts.stream().filter(p->p.getId()==id).findFirst();
    }


    public void addPosts(Post post) {
        posts.add(post);
    }

    public void deletePosts(Integer id) {
        posts = posts.stream().filter(p -> p.getId() != id).collect(Collectors.toList());
    }

    public void updatePosts(Integer id) {
        posts =
                posts.stream()
                        .map(p-> {
                            if(p.getId()==id){
                                p.setAuthor("Gebru");
                                p.setContent("updated one");
                                p.setTitle("update");
                            }
                            return  p;
                        }).collect(Collectors.toList());
    }

}
